const Rentals = () => {
  return <h1>Rentals</h1>;
};

export default Rentals;
