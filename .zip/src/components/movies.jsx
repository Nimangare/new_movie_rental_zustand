const Movies = () => {
  return <h1>Movies</h1>;
};

export default Movies;
